<?php
if(session_status() == PHP_SESSION_NONE){
  session_start();
}


include("../DB.php");
include("../navbar.php");

mysqli_select_db($conn,"complaint_system");
// FETCH ALL COMPLAINTS WITH DETAILS
$res = mysqli_query($conn, "
SELECT c.*, u.name AS user_name, cat.name AS category,
       sp.name AS spot, s.name AS sector, z.name AS zone
FROM complaints c
JOIN users u ON c.user_id = u.id
JOIN categories cat ON c.category_id = cat.id
JOIN spots sp ON c.spot_id = sp.id
JOIN sectors s ON sp.sector_id = s.id
JOIN zones z ON s.zone_id = z.id
ORDER BY c.created_at DESC
");


if($_SESSION['role'] != 'Admin'){
  echo "Access denied";
  exit();
}
else{?>

<h2>Admin Dashboard</h2>

<table border="1" cellpadding="10">
<tr>
    <th>ID</th>
    <th>Title</th>
    <th>User</th>
    <th>Category</th>
    <th>Area</th>
    <th>Status</th>
    <th>Repeated</th>
    <th>SLA</th>
    <th>Assign</th>
</tr>

<?php while($row = mysqli_fetch_assoc($res)){

    // SLA Calculation
    $created = strtotime($row['created_at']);
    $hours = (time() - $created) / 3600;

    $sla = "OK";

    if($hours > 36){
        $sla = "<span style='color:red'>Resolution Late</span>";
    }
    elseif($hours > 5){
        $sla = "<span style='color:orange'>Response Late</span>";
    }
?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['title']; ?></td>
    <td><?php echo $row['user_name']; ?></td>
    <td><?php echo $row['category']; ?></td>

    <td>
        <?php echo $row['zone']." / ".$row['sector']." / ".$row['spot']; ?>
    </td>

    <td><?php echo $row['status']; ?></td>

    <td>
        <?php echo ($row['is_repeated']) ? "<span style='color:red'>Yes</span>" : "No"; ?>
    </td>

    <td><?php echo $sla; ?></td>

    <td>
        <form method="POST" action="assign_complaint.php">
            <input type="hidden" name="cid" value="<?php echo $row['id']; ?>">

            <select name="staff_id">
            <?php
            $staff = mysqli_query($conn, "SELECT * FROM users WHERE role='Staff'");
            while($s = mysqli_fetch_assoc($staff)){
                echo "<option value='".$s['ID']."'>".$s['Name']."</option>";
            }
            ?>
            </select>

            <button>Assign</button>
        </form>
    </td>
</tr>
<?php } ?>

</table>

<?php } ?>