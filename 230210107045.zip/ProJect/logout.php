<?php
session_start();
session_destroy();
?>
<h1>You are being logout</h1>
<?php
header("Location: login.html");
?>