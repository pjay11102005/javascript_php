<?php
if(session_status() == PHP_SESSION_NONE){
  session_start();
}
$name = isset($_SESSION['name']) ? $_SESSION['name'] :'';
$role = isset($_SESSION['role']) ? $_SESSION['role'] :'';
$staff_id = $_SESSION['user_id'];

include("../navbar.php");
include("../DB.php");

mysqli_select_db($conn,"complaint_system");

// if(!isset($_SSESION['user_id'])){
//   header("Location: ../login.php");
//   exit();
// }

// FETCH ASSIGNED COMPLAINTS
$res = mysqli_query($conn, "
SELECT c.*, sp.name AS spot
FROM complaints c
JOIN spots sp ON c.spot_id = sp.id
WHERE c.assigned_to = '$staff_id'
ORDER BY c.created_at DESC
");
?>

<?php
if($_SESSION['role'] != 'Staff'){
  echo "Access denied";
  exit();
}
else{ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard-Staff</title>
</head>
<body>
  <h1>Welcome <?php echo "$name" ?> Role <?php echo "$role"?>
  <h2>Staff Dashboard</h2>

  <table border="1" cellpadding="10">
<tr>
    <th>ID</th>
    <th>Title</th>
    <th>Status</th>
    <th>Spot</th>
    <th>SLA</th>
    <th>Action</th>
</tr>

<?php while($row = mysqli_fetch_assoc($res)){

    // SLA CALCULATION
    $created = strtotime($row['created_at']);
    $now = time();

    $hours = ($now - $created) / 3600;

    $sla = "OK";

    if($hours > 36){
        $sla = "<span style='color:red'>Resolution Late</span>";
    }
    elseif($hours > 5){
        $sla = "<span style='color:orange'>Response Late</span>";
    }

?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['title']; ?></td>  
    <td><?php echo $row['status']; ?></td>
    <td><?php echo $row['spot']; ?></td>
    <td><?php echo $sla; ?></td>

    <td>
        <form method="POST" action="update_status.php">
            <input type="hidden" name="cid" value="<?php echo $row['id']; ?>">

            <select name="status">
                <option value='In Progress'>In Progress</option>
                <option value='Resolved'>Resolved</option>
                <option>Closed</option>
            </select>

            <button type="submit">Update</button>
        </form>
    </td>
</tr>
<?php } ?>

</table>

</body>
</html>
<?php }?>